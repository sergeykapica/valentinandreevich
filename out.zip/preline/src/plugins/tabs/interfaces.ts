export interface ITabs {
	options?: {};
}
