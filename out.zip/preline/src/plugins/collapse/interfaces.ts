export interface ICollapse {
	options?: {};
	
	show(): void;
	
	hide(): void;
}
