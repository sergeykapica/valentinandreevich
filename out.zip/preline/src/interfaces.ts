export interface ICollectionItem<T> {
	id: string | number;
	element: T;
}
