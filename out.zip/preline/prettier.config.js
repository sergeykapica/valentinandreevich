const config = {
	useTabs: true,
	singleQuote: true,
	bracketSameLine: true,
	arrowParens: 'always',
};

module.exports = config;
